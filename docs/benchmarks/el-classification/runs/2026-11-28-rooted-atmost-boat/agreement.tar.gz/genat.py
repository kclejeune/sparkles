#!/usr/bin/env python3
"""genat.py OUT SEED0 N: item 1229's at-most class. Individuals with at-most restrictions
(asserted, functional, or through a class), named and anonymous values over the counted role
and its subroles, cases that a minimum refutes, equalities through singletons, and query
classes that read the merged individuals by has-value restrictions. One disjunction that no
other axiom meets sends the file to the disjunctive rules."""
import sys, os, random
out, s0, n = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
os.makedirs(out, exist_ok=True)
def gen(seed):
    R = random.Random(seed)
    inds = [f'a{i}' for i in range(R.randint(3, 6))]
    I = lambda: ':' + R.choice(inds)
    cls = [f'C{i}' for i in range(R.randint(3, 6))]
    C = lambda: ':' + R.choice(cls)
    ax = []
    r = 'r0'
    if R.random() < 0.4:
        ax.append('SubObjectPropertyOf(:r1 :r0)'); sub = ['r0', 'r1']
    else:
        sub = ['r0']
    S = lambda: ':' + R.choice(sub)
    h = I(); k = R.choice([1, 1, 1, 2])
    how = R.randrange(3)
    if how == 0: ax.append(f'ClassAssertion(ObjectMaxCardinality({k} :r0 owl:Thing) {h})')
    elif how == 1: ax.append('FunctionalObjectProperty(:r0)'); k = 1
    else:
        m = C(); ax.append(f'SubClassOf({m} ObjectMaxCardinality({k} :r0 owl:Thing))'); ax.append(f'ClassAssertion({m} {h})')
    # values of h over r0: named, anonymous, and conditional
    for _ in range(R.randint(1, k + 2)):
        x = R.randrange(4)
        if x < 2: ax.append(f'ObjectPropertyAssertion({S()} {h} {I()})')
        elif x == 2:
            d = C(); ax.append(f'ClassAssertion({d} {h})'); ax.append(f'SubClassOf({d} ObjectSomeValuesFrom({S()} {C()}))')
        else:
            d = C(); ax.append(f'SubClassOf({d} ObjectMinCardinality({R.choice([2, 3])} :r0 owl:Thing))')
            ax.append(f'ClassAssertion(ObjectUnionOf({R.choice([f"ObjectOneOf({I()})", C()])} {d}) {h})')
    if R.random() < 0.3:
        ax.append(f'SubClassOf(owl:Thing ObjectUnionOf(ObjectOneOf({I()}) {C()}))')
    if R.random() < 0.3:
        ax.append(f'SubClassOf({C()} ObjectOneOf({I()}))')
    # conditional cases under K
    if R.random() < 0.3:
        b = I(); ax.append(f'ObjectPropertyAssertion(:r5 {b} {h})')
        ax.append(f'SubClassOf(:K ObjectSomeValuesFrom(:p ObjectIntersectionOf(ObjectOneOf({b}) ObjectAllValuesFrom(:r5 ObjectUnionOf({C()} {C()})))))')
    # facts and readers
    for _ in range(R.randint(1, 3)): ax.append(f'ClassAssertion({C()} {I()})')
    for q in ['K', 'L']:
        for _ in range(R.randint(1, 2)):
            ax.append(f'SubClassOf(:{q} ObjectHasValue(:{R.choice(["p", "t"])} {I()}))')
    for _ in range(R.randint(1, 3)):
        ax.append(f'SubClassOf(ObjectSomeValuesFrom(:{R.choice(["p", "t"])} {C()}) :{R.choice(["Ans", "Ans2"])})')
    if R.random() < 0.3: ax.append(f'DisjointClasses({C()} {C()})')
    ax.append('SubClassOf(:Q ObjectUnionOf(:Q1 :Q2))')
    decl = [f'Declaration(Class(:{c}))' for c in cls + ['K', 'L', 'Ans', 'Ans2', 'Q', 'Q1', 'Q2']] + [f'Declaration(NamedIndividual(:{i}))' for i in inds]
    return 'Prefix(:=<http://example.org/a#>)\nPrefix(owl:=<http://www.w3.org/2002/07/owl#>)\nOntology(<http://example.org/a#o>\n' + '\n'.join(decl + ax) + '\n)\n'
for s in range(s0, s0 + n):
    open(os.path.join(out, f'a{s}.ofn'), 'w').write(gen(s))
