SUB http://example.org/a#C3 http://example.org/a#C2
END
