SUB http://example.org/a#C2 http://example.org/a#C0
SUB http://example.org/a#K http://example.org/a#Ans
END
