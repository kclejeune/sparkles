SUB http://example.org/a#C0 http://example.org/a#C4
SUB http://example.org/a#K http://example.org/a#Ans2
SUB http://example.org/a#L http://example.org/a#Ans2
END
