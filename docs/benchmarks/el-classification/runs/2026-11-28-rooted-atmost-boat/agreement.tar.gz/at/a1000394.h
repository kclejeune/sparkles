UNSAT http://example.org/a#C1
SUB http://example.org/a#Ans http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#Ans2 http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#C0 http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#C2 http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#C3 http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#K http://example.org/a#Ans2
SUB http://example.org/a#K http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#L http://example.org/a#Ans2
SUB http://example.org/a#L http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#Q http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#Q1 http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#Q2 http://www.w3.org/2002/07/owl#Thing
TOP http://www.w3.org/2002/07/owl#Thing
END
