SUB http://example.org/a#C0 http://example.org/a#C3
END
