SUB http://example.org/a#Ans http://example.org/a#C1
SUB http://example.org/a#Ans http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#Ans2 http://example.org/a#C1
SUB http://example.org/a#Ans2 http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#C0 http://example.org/a#C1
SUB http://example.org/a#C0 http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#C1 http://www.w3.org/2002/07/owl#Thing
TOP http://example.org/a#C1
SUB http://example.org/a#C2 http://example.org/a#C1
SUB http://example.org/a#C2 http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#C3 http://example.org/a#C1
SUB http://example.org/a#C3 http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#C4 http://example.org/a#C1
SUB http://example.org/a#C4 http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#K http://example.org/a#Ans
SUB http://example.org/a#K http://example.org/a#C1
SUB http://example.org/a#K http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#L http://example.org/a#Ans
SUB http://example.org/a#L http://example.org/a#C1
SUB http://example.org/a#L http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#Q http://example.org/a#C1
SUB http://example.org/a#Q http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#Q1 http://example.org/a#C1
SUB http://example.org/a#Q1 http://www.w3.org/2002/07/owl#Thing
SUB http://example.org/a#Q2 http://example.org/a#C1
SUB http://example.org/a#Q2 http://www.w3.org/2002/07/owl#Thing
SUB http://www.w3.org/2002/07/owl#Thing http://example.org/a#C1
TOP http://www.w3.org/2002/07/owl#Thing
END
