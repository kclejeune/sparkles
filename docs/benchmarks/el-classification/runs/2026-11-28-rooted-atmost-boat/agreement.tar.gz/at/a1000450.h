SUB http://example.org/a#C1 http://example.org/a#C2
SUB http://example.org/a#K http://example.org/a#Ans2
SUB http://example.org/a#L http://example.org/a#Ans2
END
