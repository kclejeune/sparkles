| query | rows | with the index (ms) | without (ms) | speedup | rewrites off (ms) | same answer |
|---|---:|---:|---:|---:|---:|:-:|
| geo-q1-within | 2861 | 35.4 ± 0.5 | 389.9 ± 6.2 | 11.0× | — | yes |
| geo-q2-distance | 85 | 16.8 ± 0.9 | 2484.2 ± 8.5 | 148.2× | — | yes |
| geo-q3-nearby | 10 | 14.9 ± 1.4 | 380.8 ± 9.4 | 25.6× | — | yes |
| geo-q4-withinbox | 1 | 73.6 ± 0.7 | 392.8 ± 6.5 | 5.3× | — | yes |
| geo-q5-points-per-state | 562 | 85.9 ± 2.0 | 142.0 ± 3.5 | 1.7× | — | yes |
| geo-q6-touching-counties | 1 | 1951.1 ± 1.3 | 2062.9 ± 10.5 | 1.1× | — | yes |
| geo-q7-knn | 10 | 12.1 ± 1.9 | 259.9 ± 5.3 | 21.5× | 205.3 ± 3.1 | yes |
| geo-q8-area | 1 | 731.3 ± 0.9 | 934.7 ± 5.4 | 1.3× | — | yes |
| geo-q9-star | 1374 | 36.5 ± 0.8 | 394.0 ± 11.0 | 10.8× | — | yes |

index: 180640 rows, 180640 literals, 13.8 MiB (tree 0.0, geometries 13.8)
