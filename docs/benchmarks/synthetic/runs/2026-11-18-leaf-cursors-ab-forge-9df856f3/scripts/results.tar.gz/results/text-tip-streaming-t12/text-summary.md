# Full-text search: 1,052,807 triples

## Text index build

|  | sparkles |
|---|---:|
| build (s) | — |
| size on disk (MB) | — |

## Answers

Rows per engine, or the number of hits for a COUNT query. Hit sets compare `?s`, the
matched literal and any joined variables, never the score. The top 10 of a common word
are compared by row count only, because its hits tie on score. An answer marked
"differs" disagrees with the majority, and that engine's time is not ranked.

| query | sparkles |
|---|---:|
| rare-top10 | 2 |
| common-top10 | 10 |
| common-count | 4937 |
| text-join | 363 |
| conjunction | 278 |
| highlight | 4937 |
| stemmed | 51 |

## Query times

Mean ± standard deviation in ms of an HTTP request with curl (TSV results).

| query | sparkles |
|---|---:|
| rare-top10 | **4.2 ± 0.1** |
| common-top10 | **4.5 ± 0.1** |
| common-count | **4.9 ± 0.1** |
| text-join | **5.7 ± 0.1** |
| conjunction | **4.6 ± 0.2** |
| highlight | **10.7 ± 0.2** |
| stemmed | **4.3 ± 0.1** |
