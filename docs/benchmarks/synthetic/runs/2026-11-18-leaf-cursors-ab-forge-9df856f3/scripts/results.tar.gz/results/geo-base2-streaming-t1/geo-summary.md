| query | rows | with the index (ms) | without (ms) | speedup | rewrites off (ms) | same answer |
|---|---:|---:|---:|---:|---:|:-:|
| geo-q1-within | 2861 | 35.4 ± 0.9 | 388.3 ± 11.0 | 11.0× | — | yes |
| geo-q2-distance | 85 | 13.0 ± 3.1 | 2481.7 ± 9.4 | 191.4× | — | yes |
| geo-q3-nearby | 10 | 13.8 ± 2.4 | 382.2 ± 9.2 | 27.8× | — | yes |
| geo-q4-withinbox | 1 | 72.8 ± 0.7 | 392.7 ± 6.9 | 5.4× | — | yes |
| geo-q5-points-per-state | 562 | 87.2 ± 2.9 | 137.5 ± 3.3 | 1.6× | — | yes |
| geo-q6-touching-counties | 1 | 1929.5 ± 3.9 | 2055.8 ± 15.9 | 1.1× | — | yes |
| geo-q7-knn | 10 | 7.1 ± 2.5 | 259.3 ± 3.2 | 36.6× | 205.4 ± 2.4 | yes |
| geo-q8-area | 1 | 743.3 ± 9.8 | 948.0 ± 8.6 | 1.3× | — | yes |
| geo-q9-star | 1374 | 37.3 ± 0.6 | 394.7 ± 10.6 | 10.6× | — | yes |

index: 180640 rows, 180640 literals, 13.8 MiB (tree 0.0, geometries 13.8)
