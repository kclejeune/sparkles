| query | rows | with the index (ms) | without (ms) | speedup | rewrites off (ms) | same answer |
|---|---:|---:|---:|---:|---:|:-:|
| geo-q1-within | 2861 | 35.1 ± 0.6 | 383.9 ± 9.9 | 10.9× | — | yes |
| geo-q2-distance | 85 | 15.7 ± 1.6 | 2475.9 ± 7.8 | 157.9× | — | yes |
| geo-q3-nearby | 10 | 16.2 ± 2.8 | 376.7 ± 8.4 | 23.2× | — | yes |
| geo-q4-withinbox | 1 | 73.9 ± 0.6 | 394.7 ± 7.2 | 5.3× | — | yes |
| geo-q5-points-per-state | 562 | 83.8 ± 2.6 | 138.0 ± 5.0 | 1.6× | — | yes |
| geo-q6-touching-counties | 1 | 1935.1 ± 6.3 | 2036.0 ± 18.7 | 1.1× | — | yes |
| geo-q7-knn | 10 | 10.1 ± 2.2 | 258.6 ± 4.8 | 25.5× | 207.7 ± 2.5 | yes |
| geo-q8-area | 1 | 738.0 ± 1.1 | 941.3 ± 5.7 | 1.3× | — | yes |
| geo-q9-star | 1374 | 37.7 ± 0.8 | 395.7 ± 10.6 | 10.5× | — | yes |

index: 180640 rows, 180640 literals, 13.8 MiB (tree 0.0, geometries 13.8)
