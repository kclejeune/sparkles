| query | rows | with the index (ms) | without (ms) | speedup | rewrites off (ms) | same answer |
|---|---:|---:|---:|---:|---:|:-:|
| geo-q1-within | 2861 | 35.0 ± 0.6 | 395.8 ± 8.9 | 11.3× | — | yes |
| geo-q2-distance | 85 | 16.2 ± 1.9 | 2497.2 ± 18.4 | 154.5× | — | yes |
| geo-q3-nearby | 10 | 17.0 ± 0.9 | 385.7 ± 7.7 | 22.7× | — | yes |
| geo-q4-withinbox | 1 | 73.9 ± 0.5 | 398.4 ± 10.2 | 5.4× | — | yes |
| geo-q5-points-per-state | 562 | 85.5 ± 1.6 | 142.1 ± 6.4 | 1.7× | — | yes |
| geo-q6-touching-counties | 1 | 1956.5 ± 2.5 | 2067.0 ± 5.7 | 1.1× | — | yes |
| geo-q7-knn | 10 | 7.4 ± 3.1 | 261.5 ± 6.0 | 35.1× | 206.5 ± 2.1 | yes |
| geo-q8-area | 1 | 731.8 ± 0.7 | 937.1 ± 9.6 | 1.3× | — | yes |
| geo-q9-star | 1374 | 37.5 ± 0.4 | 396.9 ± 14.9 | 10.6× | — | yes |

index: 180640 rows, 180640 literals, 13.8 MiB (tree 0.0, geometries 13.8)
