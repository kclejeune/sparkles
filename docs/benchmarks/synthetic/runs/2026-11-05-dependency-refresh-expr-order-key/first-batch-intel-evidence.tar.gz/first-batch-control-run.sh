#!/usr/bin/env bash
set -euo pipefail
cd /home/kclejeune/lanes/item701-acceptance-6724/first-batch-intel
test ! -e results
for name in rustc cargo mbx java qlever-server oxigraph fluree sparkles A B; do
  if pgrep -x "$name" > /dev/null; then
    printf 'competing process: %s\n' "$name" >&2
    exit 1
  fi
done
python3 - <<'PY'
from pathlib import Path
import hashlib,json
j=json.loads(Path('control-receipt.json').read_text())
for name,wanted in j['files'].items():
 with Path(name).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==wanted,name
with Path('data.nt.zst').open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==j['data']['sha256']
assert Path('build-origin/build-config.json').read_bytes()==Path('build-batch/build-config.json').read_bytes()
assert Path('build-origin/compiler-comment.txt').read_bytes()==Path('build-batch/compiler-comment.txt').read_bytes()
PY
df -Pk .
exec env -i HOME="$HOME" PATH="$PATH" LC_ALL=C.UTF-8 bash nsc-bench-remote.sh
