#!/usr/bin/env bash
set -euo pipefail
cd /home/kclejeune/lanes/item701-acceptance-6724/first-batch-intel
printf 'both Forge locks held; verifying uncompressed binaries\n'
origin_sha=$(zstd -qdc "$(readlink -f bin-A.zst)" | sha256sum | cut -d' ' -f1)
batch_sha=$(zstd -qdc "$(readlink -f bin-B.zst)" | sha256sum | cut -d' ' -f1)
test "$origin_sha" = 891fc6f6317372add5a237aa730fe01c1e2a59ea608ca703c7dca3d99f966016
test "$batch_sha" = a15cc9b3d2de293f3ceefec79ce975531fb34d2437d8201e5ced56f70dc9bc61
printf 'verified origin=%s batch=%s\n' "$origin_sha" "$batch_sha"
exec bash first-batch-control-run.sh
